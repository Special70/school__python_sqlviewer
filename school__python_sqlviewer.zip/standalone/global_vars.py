import sqlite3
# import tkinter as tk
# from tkinter import ttk

connection = sqlite3.connect("hardwareDB.db")
cursor = connection.cursor()