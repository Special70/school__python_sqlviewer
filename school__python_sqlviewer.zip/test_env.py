from standalone.functions.print_table import print_table
from functions import order_products

x = order_products.employee_validator("4")

print(x)